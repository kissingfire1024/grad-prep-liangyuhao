SEALED FINAL REPLICATION COHORT
Do not use for prompt tuning, hyperparameters, data examples or human feedback prior to protocol freeze.
After freeze, train a NEW model using these final training items with the already fixed recipe and then evaluate the heldout QA.
A completely untrained patient code is NOT a fair parametric-memory test.
